from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone

# ===== LINHAS DE PRODUÇÃO =====

class LinhaProducao(models.Model):
    """Linha de produção completa"""
    codigo = models.CharField(max_length=20, unique=True, verbose_name='Código da Linha')
    nome = models.CharField(max_length=100, verbose_name='Nome da Linha')
    descricao = models.TextField(blank=True, verbose_name='Descrição')
    localizacao = models.CharField(max_length=200, verbose_name='Localização')
    ativa = models.BooleanField(default=True, verbose_name='Linha Ativa')
    velocidade_planejada = models.FloatField(
        validators=[MinValueValidator(0)],
        verbose_name='Velocidade Planejada (unid/min)',
        help_text='Velocidade planejada da linha completa'
    )
    meta_producao_hora = models.IntegerField(
        validators=[MinValueValidator(0)],
        verbose_name='Meta Produção/Hora'
    )
    meta_producao_turno = models.IntegerField(
        validators=[MinValueValidator(0)],
        verbose_name='Meta Produção/Turno (8h)'
    )
    meta_oee = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=85.0,
        verbose_name='Meta OEE (%)',
        help_text='Meta de OEE para a linha'
    )
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Linha de Produção'
        verbose_name_plural = 'Linhas de Produção'
        ordering = ['codigo']
    
    def __str__(self):
        return f'{self.codigo} - {self.nome}'

# ===== CONEXÕES OPC =====

class ConexaoOPC(models.Model):
    """Configuração de conexão OPC UA"""
    nome = models.CharField(max_length=100, unique=True, verbose_name='Nome da Conexão')
    url_servidor = models.CharField(
        max_length=255,
        verbose_name='URL do Servidor OPC',
        help_text='Ex: opc.tcp://192.168.1.10:4840'
    )
    namespace_prefix = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='Prefixo do Namespace',
        help_text='Ex: ns=2;s='
    )
    usuario = models.CharField(max_length=100, blank=True, verbose_name='Usuário')
    senha = models.CharField(max_length=100, blank=True, verbose_name='Senha')
    timeout = models.IntegerField(
        default=5,
        validators=[MinValueValidator(1)],
        verbose_name='Timeout (segundos)'
    )
    ativa = models.BooleanField(default=True, verbose_name='Conexão Ativa')
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Conexão OPC'
        verbose_name_plural = 'Conexões OPC'
        ordering = ['nome']
    
    def __str__(self):
        return f'{self.nome} ({self.url_servidor})'

# ===== EQUIPAMENTOS =====

class TipoEquipamento(models.TextChoices):
    ENCHEDORA = 'ENCHEDORA', 'Enchedora'
    BALANCA = 'BALANCA', 'Balança'
    ENCAIXOTADORA = 'ENCAIXOTADORA', 'Encaixotadora'
    ENVOLVEDORA = 'ENVOLVEDORA', 'Envolvedora'

class StatusEquipamento(models.TextChoices):
    ATIVO = 'ATIVO', 'Ativo'
    INATIVO = 'INATIVO', 'Inativo'
    MANUTENCAO = 'MANUTENCAO', 'Em Manutenção'

# ===== NOVO: ESTADOS INDUSTRIAIS =====

class EstadoEquipamento(models.TextChoices):
    """Estados industriais para cálculo de OEE"""
    RUN = 'RUN', 'Produzindo'
    WAIT_PREV = 'WAIT_PREV', 'Aguardando equipamento anterior'
    BLOCK_NEXT = 'BLOCK_NEXT', 'Equipamento seguinte bloqueado'
    FAULT = 'FAULT', 'Falha'
    SETUP = 'SETUP', 'Setup / Troca SKU'
    TESTE_PROJ = 'TESTE_PROJ', 'Teste de Projeto'
    AGUARD_MNT = 'AGUARD_MNT', 'Aguardando Manutenção'
    MANUTENCAO = 'MANUTENCAO', 'Em Manutenção'
    FALTA_MAT = 'FALTA_MAT', 'Falta de Material'
    OUTRO = 'OUTRO', 'Outro'

class Equipamento(models.Model):
    """Equipamento individual dentro de uma linha"""
    linha = models.ForeignKey(
        LinhaProducao,
        on_delete=models.CASCADE,
        related_name='equipamentos',
        verbose_name='Linha de Produção'
    )
    nome = models.CharField(max_length=100, unique=True, verbose_name='Nome do Equipamento')
    codigo = models.CharField(max_length=50, unique=True, verbose_name='Código')
    tipo = models.CharField(max_length=20, choices=TipoEquipamento.choices, verbose_name='Tipo')
    ordem_na_linha = models.IntegerField(
        default=1,
        verbose_name='Ordem na Linha',
        help_text='Posição do equipamento na sequência da linha (1, 2, 3...)'
    )
    localizacao = models.CharField(max_length=200, verbose_name='Localização')
    status = models.CharField(
        max_length=20,
        choices=StatusEquipamento.choices,
        default=StatusEquipamento.ATIVO,
        verbose_name='Status'
    )
    velocidade_nominal = models.FloatField(
        validators=[MinValueValidator(0)],
        verbose_name='Velocidade Nominal (unid/min)',
        help_text='Velocidade nominal do equipamento'
    )
    velocidade_maxima = models.FloatField(
        validators=[MinValueValidator(0)],
        verbose_name='Velocidade Máxima (unid/min)'
    )
    meta_oee = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=85.0,
        verbose_name='Meta OEE (%)',
        help_text='Meta de OEE para o equipamento'
    )
    temperatura_min = models.FloatField(null=True, blank=True, verbose_name='Temp. Mínima (°C)')
    temperatura_max = models.FloatField(null=True, blank=True, verbose_name='Temp. Máxima (°C)')
    pressao_min = models.FloatField(null=True, blank=True, verbose_name='Pressão Mínima (PSI)')
    pressao_max = models.FloatField(null=True, blank=True, verbose_name='Pressão Máxima (PSI)')
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    observacoes = models.TextField(blank=True, verbose_name='Observações')
    
    class Meta:
        verbose_name = 'Equipamento'
        verbose_name_plural = 'Equipamentos'
        ordering = ['linha', 'ordem_na_linha']
    
    def __str__(self):
        return f'{self.nome} ({self.get_tipo_display()})'

# ===== TAGS DE COLETA =====

class TipoDado(models.TextChoices):
    INT = 'INT', 'Inteiro'
    FLOAT = 'FLOAT', 'Decimal'
    STRING = 'STRING', 'Texto'
    BOOL = 'BOOL', 'Booleano'

class TagColeta(models.Model):
    """Tag OPC para coleta de dados de um equipamento"""
    equipamento = models.ForeignKey(
        Equipamento,
        on_delete=models.CASCADE,
        related_name='tags_coleta',
        verbose_name='Equipamento'
    )
    conexao = models.ForeignKey(
        ConexaoOPC,
        on_delete=models.CASCADE,
        related_name='tags',
        verbose_name='Conexão OPC'
    )
    nome_metrica = models.CharField(
        max_length=100,
        verbose_name='Nome da Métrica',
        help_text='Ex: velocidade_atual, contagem_entrada, contagem_saida, estado'
    )
    node_id = models.CharField(
        max_length=255,
        verbose_name='Node ID',
        help_text='Ex: ns=2;s=Linha1.Enchedora.Velocidade'
    )
    tipo_dado = models.CharField(
        max_length=10,
        choices=TipoDado.choices,
        default=TipoDado.FLOAT,
        verbose_name='Tipo de Dado'
    )
    unidade = models.CharField(max_length=20, blank=True, verbose_name='Unidade')
    fator_conversao = models.FloatField(
        default=1.0,
        verbose_name='Fator de Conversão',
        help_text='Multiplicador aplicado ao valor lido'
    )
    ativa = models.BooleanField(default=True, verbose_name='Tag Ativa')
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Tag de Coleta'
        verbose_name_plural = 'Tags de Coleta'
        ordering = ['equipamento', 'nome_metrica']
        unique_together = ['equipamento', 'nome_metrica']
    
    def __str__(self):
        return f'{self.equipamento.nome} - {self.nome_metrica}'

# ===== SENSORES =====

class TipoSensor(models.TextChoices):
    ENTRADA = 'ENTRADA', 'Sensor de Entrada'
    SAIDA = 'SAIDA', 'Sensor de Saída'
    TEMPERATURA = 'TEMPERATURA', 'Sensor de Temperatura'
    PRESSAO = 'PRESSAO', 'Sensor de Pressão'
    VELOCIDADE = 'VELOCIDADE', 'Sensor de Velocidade'
    NIVEL = 'NIVEL', 'Sensor de Nível'

class Sensor(models.Model):
    """Sensor associado a um equipamento ou linha"""
    equipamento = models.ForeignKey(
        Equipamento,
        on_delete=models.CASCADE,
        related_name='sensores',
        null=True,
        blank=True,
        verbose_name='Equipamento'
    )
    linha = models.ForeignKey(
        LinhaProducao,
        on_delete=models.CASCADE,
        related_name='sensores',
        null=True,
        blank=True,
        verbose_name='Linha de Produção',
        help_text='Para sensores de entrada/saída da linha inteira'
    )
    codigo = models.CharField(max_length=50, unique=True, verbose_name='Código do Sensor')
    nome = models.CharField(max_length=100, verbose_name='Nome do Sensor')
    tipo = models.CharField(max_length=20, choices=TipoSensor.choices, verbose_name='Tipo')
    tag_influxdb = models.CharField(
        max_length=100,
        verbose_name='Tag InfluxDB',
        help_text='Nome do campo no InfluxDB (ex: contagem_entrada, temperatura)'
    )
    unidade = models.CharField(max_length=20, blank=True, verbose_name='Unidade de Medida')
    ativo = models.BooleanField(default=True, verbose_name='Sensor Ativo')
    valor_min = models.FloatField(null=True, blank=True, verbose_name='Valor Mínimo')
    valor_max = models.FloatField(null=True, blank=True, verbose_name='Valor Máximo')
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    observacoes = models.TextField(blank=True, verbose_name='Observações')
    
    class Meta:
        verbose_name = 'Sensor'
        verbose_name_plural = 'Sensores'
        ordering = ['linha', 'equipamento', 'tipo']
    
    def __str__(self):
        if self.equipamento:
            return f'{self.codigo} - {self.nome} ({self.equipamento.nome})'
        elif self.linha:
            return f'{self.codigo} - {self.nome} (Linha {self.linha.codigo})'
        return f'{self.codigo} - {self.nome}'
    
    def clean(self):
        from django.core.exceptions import ValidationError
        if not self.equipamento and not self.linha:
            raise ValidationError('Sensor deve estar associado a um equipamento ou linha')
        if self.equipamento and self.linha:
            raise ValidationError('Sensor não pode estar associado a equipamento e linha simultaneamente')

# ===== NOVO: TURNOS DE PRODUÇÃO =====

class TurnoProducao(models.Model):
    """Definição de turnos de produção"""
    nome = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='Nome do Turno',
        help_text='Ex: Turno A, Turno B, Turno C'
    )
    codigo = models.CharField(
        max_length=10,
        unique=True,
        verbose_name='Código',
        help_text='Ex: A, B, C'
    )
    hora_inicio = models.TimeField(verbose_name='Hora de Início')
    hora_fim = models.TimeField(verbose_name='Hora de Fim')
    duracao_horas = models.FloatField(
        validators=[MinValueValidator(0)],
        verbose_name='Duração (horas)',
        help_text='Duração do turno em horas'
    )
    ativo = models.BooleanField(default=True, verbose_name='Turno Ativo')
    observacoes = models.TextField(blank=True, verbose_name='Observações')
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Turno de Produção'
        verbose_name_plural = 'Turnos de Produção'
        ordering = ['hora_inicio']
    
    def __str__(self):
        return f'{self.nome} ({self.hora_inicio.strftime("%H:%M")} - {self.hora_fim.strftime("%H:%M")})'

# ===== NOVO: CALENDÁRIO DE PRODUÇÃO =====

class CalendarioProducao(models.Model):
    """Calendário de produção por linha e turno"""
    data = models.DateField(verbose_name='Data', db_index=True)
    linha = models.ForeignKey(
        LinhaProducao,
        on_delete=models.CASCADE,
        related_name='calendario',
        verbose_name='Linha de Produção'
    )
    turno = models.ForeignKey(
        TurnoProducao,
        on_delete=models.CASCADE,
        related_name='calendario',
        verbose_name='Turno'
    )
    programado = models.BooleanField(
        default=True,
        verbose_name='Programado',
        help_text='Se a linha deve produzir neste dia/turno'
    )
    meta_producao_turno = models.IntegerField(
        validators=[MinValueValidator(0)],
        verbose_name='Meta de Produção do Turno',
        help_text='Meta de produção para este turno específico'
    )
    observacoes = models.TextField(blank=True, verbose_name='Observações')
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Calendário de Produção'
        verbose_name_plural = 'Calendários de Produção'
        ordering = ['-data', 'linha', 'turno']
        unique_together = ['data', 'linha', 'turno']
    
    def __str__(self):
        status = 'Programado' if self.programado else 'Não Programado'
        return f'{self.linha.codigo} - {self.data} - {self.turno.codigo} ({status})'

# ===== NOVO: EVENTOS DE ESTADO =====

class EventoEstadoEquipamento(models.Model):
    """Registro de mudanças de estado de equipamentos para cálculo de tempos"""
    equipamento = models.ForeignKey(
        Equipamento,
        on_delete=models.CASCADE,
        related_name='eventos_estado',
        verbose_name='Equipamento'
    )
    estado = models.CharField(
        max_length=20,
        choices=EstadoEquipamento.choices,
        verbose_name='Estado'
    )
    inicio = models.DateTimeField(verbose_name='Início', db_index=True)
    fim = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='Fim',
        help_text='Null enquanto o evento estiver aberto'
    )
    duracao_segundos = models.IntegerField(
        null=True,
        blank=True,
        verbose_name='Duração (segundos)',
        help_text='Calculado automaticamente ao fechar o evento'
    )
    origem = models.CharField(
        max_length=20,
        choices=[('OPC', 'OPC UA'), ('MANUAL', 'Manual'), ('SISTEMA', 'Sistema')],
        default='OPC',
        verbose_name='Origem'
    )
    observacao = models.TextField(blank=True, verbose_name='Observação')
    criado_em = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Evento de Estado'
        verbose_name_plural = 'Eventos de Estado'
        ordering = ['-inicio']
        indexes = [
            models.Index(fields=['equipamento', 'inicio']),
            models.Index(fields=['equipamento', 'estado']),
        ]
    
    def __str__(self):
        if self.fim:
            return f'{self.equipamento.nome} - {self.get_estado_display()} ({self.duracao_segundos}s)'
        return f'{self.equipamento.nome} - {self.get_estado_display()} (Em andamento)'
    
    def save(self, *args, **kwargs):
        # Calcula duração automaticamente se fim estiver preenchido
        if self.fim and self.inicio:
            delta = self.fim - self.inicio
            self.duracao_segundos = int(delta.total_seconds())
        super().save(*args, **kwargs)
    
    @classmethod
    def fechar_evento_aberto(cls, equipamento):
        """Fecha o último evento aberto do equipamento"""
        evento_aberto = cls.objects.filter(
            equipamento=equipamento,
            fim__isnull=True
        ).first()
        
        if evento_aberto:
            evento_aberto.fim = timezone.now()
            evento_aberto.save()
            return evento_aberto
        return None
    
    @classmethod
    def calcular_tempos_por_estado(cls, equipamento, inicio, fim):
        """
        Calcula tempos por categoria de estado em um intervalo
        
        Retorna dict com:
        - tempo_producao (RUN)
        - tempo_parada (FAULT, FALTA_MAT, AGUARD_MNT, WAIT_PREV, BLOCK_NEXT)
        - tempo_setup (SETUP)
        - tempo_nao_programado (MANUTENCAO, TESTE_PROJ)
        """
        eventos = cls.objects.filter(
            equipamento=equipamento,
            inicio__lt=fim,
            fim__gte=inicio
        ).exclude(fim__isnull=True)
        
        tempos = {
            'tempo_producao': 0,
            'tempo_parada': 0,
            'tempo_setup': 0,
            'tempo_nao_programado': 0,
        }
        
        # Mapeamento de estados para categorias
        estados_producao = [EstadoEquipamento.RUN]
        estados_parada = [
            EstadoEquipamento.FAULT,
            EstadoEquipamento.FALTA_MAT,
            EstadoEquipamento.AGUARD_MNT,
            EstadoEquipamento.WAIT_PREV,
            EstadoEquipamento.BLOCK_NEXT,
        ]
        estados_setup = [EstadoEquipamento.SETUP]
        estados_nao_programado = [
            EstadoEquipamento.MANUTENCAO,
            EstadoEquipamento.TESTE_PROJ,
        ]
        
        for evento in eventos:
            # Ajusta início e fim do evento para o intervalo solicitado
            evento_inicio = max(evento.inicio, inicio)
            evento_fim = min(evento.fim, fim)
            duracao = (evento_fim - evento_inicio).total_seconds()
            
            if duracao <= 0:
                continue
            
            # Classifica o tempo
            if evento.estado in estados_producao:
                tempos['tempo_producao'] += duracao
            elif evento.estado in estados_parada:
                tempos['tempo_parada'] += duracao
            elif evento.estado in estados_setup:
                tempos['tempo_setup'] += duracao
            elif evento.estado in estados_nao_programado:
                tempos['tempo_nao_programado'] += duracao
        
        # Converte para minutos
        for key in tempos:
            tempos[key] = tempos[key] / 60.0
        
        return tempos

# ===== MÉTRICAS E PRODUÇÃO (ATUALIZADO) =====

class MetricaProducao(models.Model):
    """Métricas agregadas de produção com cálculo real de OEE"""
    linha = models.ForeignKey(
        LinhaProducao,
        on_delete=models.CASCADE,
        related_name='metricas',
        verbose_name='Linha'
    )
    equipamento = models.ForeignKey(
        Equipamento,
        on_delete=models.CASCADE,
        related_name='metricas',
        null=True,
        blank=True,
        verbose_name='Equipamento',
        help_text='Deixe em branco para métricas da linha inteira'
    )
    data_hora = models.DateTimeField(verbose_name='Data/Hora', db_index=True)
    periodo = models.CharField(
        max_length=20,
        choices=[
            ('HORA', 'Hora'),
            ('TURNO', 'Turno'),
            ('DIA', 'Dia'),
            ('SEMANA', 'Semana'),
            ('MES', 'Mês'),
            ('ANO', 'Ano'),
        ],
        default='HORA',
        verbose_name='Período'
    )
    turno = models.CharField(max_length=20, blank=True, verbose_name='Turno')
    
    # Contadores de entrada/saída
    contagem_entrada = models.IntegerField(default=0, verbose_name='Contagem Entrada')
    contagem_saida = models.IntegerField(default=0, verbose_name='Contagem Saída')
    descarte = models.IntegerField(default=0, verbose_name='Descarte')
    percentual_descarte = models.FloatField(default=0.0, verbose_name='% Descarte')
    
    # Velocidades
    velocidade_planejada = models.FloatField(default=0.0, verbose_name='Velocidade Planejada')
    velocidade_real = models.FloatField(default=0.0, verbose_name='Velocidade Real')
    
    # Tempos (em minutos)
    tempo_programado = models.FloatField(default=0.0, verbose_name='Tempo Programado (min)')
    tempo_disponivel = models.FloatField(default=0.0, verbose_name='Tempo Disponível (min)')
    tempo_producao = models.FloatField(default=0.0, verbose_name='Tempo Produção (min)')
    tempo_parada = models.FloatField(default=0.0, verbose_name='Tempo Parada (min)')
    tempo_setup = models.FloatField(default=0.0, verbose_name='Tempo Setup (min)')
    tempo_nao_programado = models.FloatField(default=0.0, verbose_name='Tempo Não Programado (min)')
    
    # KPIs
    disponibilidade = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name='Disponibilidade (%)'
    )
    performance = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name='Performance (%)'
    )
    qualidade = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name='Qualidade (%)'
    )
    oee = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name='OEE (%)'
    )
    
    calculado_em = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Métrica de Produção'
        verbose_name_plural = 'Métricas de Produção'
        ordering = ['-data_hora']
        unique_together = ['linha', 'equipamento', 'data_hora', 'periodo']
    
    def __str__(self):
        if self.equipamento:
            return f'{self.equipamento.nome} - {self.data_hora} - OEE: {self.oee:.1f}%'
        return f'{self.linha.codigo} - {self.data_hora} - OEE: {self.oee:.1f}%'
    
    def save(self, *args, **kwargs):
        """Calcula KPIs automaticamente antes de salvar"""
        # Calcula descarte
        if self.contagem_entrada > 0:
            self.descarte = self.contagem_entrada - self.contagem_saida
            self.percentual_descarte = (self.descarte / self.contagem_entrada) * 100
        else:
            self.descarte = 0
            self.percentual_descarte = 0.0
        
        # Calcula tempo disponível
        self.tempo_disponivel = self.tempo_programado - self.tempo_nao_programado
        
        # Calcula Disponibilidade (A)
        if self.tempo_disponivel > 0:
            self.disponibilidade = min(100, (self.tempo_producao / self.tempo_disponivel) * 100)
        else:
            self.disponibilidade = 0.0
        
        # Calcula Performance (P)
        if self.tempo_producao > 0 and self.velocidade_planejada > 0:
            producao_teorica = self.velocidade_planejada * self.tempo_producao
            if producao_teorica > 0:
                self.performance = min(100, (self.contagem_saida / producao_teorica) * 100)
            else:
                self.performance = 0.0
        else:
            self.performance = 0.0
        
        # Calcula Qualidade (Q)
        if self.contagem_entrada > 0:
            self.qualidade = min(100, (self.contagem_saida / self.contagem_entrada) * 100)
        else:
            self.qualidade = 0.0
        
        # Calcula OEE
        self.oee = (self.disponibilidade * self.performance * self.qualidade) / 10000
        
        super().save(*args, **kwargs)

# ===== DEFEITOS =====

class Defeito(models.Model):
    """Registro de defeitos"""
    linha = models.ForeignKey(
        LinhaProducao,
        on_delete=models.CASCADE,
        related_name='defeitos',
        null=True,
        blank=True,
        verbose_name='Linha'
    )
    equipamento = models.ForeignKey(
        Equipamento,
        on_delete=models.CASCADE,
        related_name='defeitos',
        null=True,
        blank=True,
        verbose_name='Equipamento'
    )
    data_hora = models.DateTimeField(default=timezone.now, verbose_name='Data/Hora')
    tipo_defeito = models.CharField(max_length=100, verbose_name='Tipo de Defeito')
    descricao = models.TextField(verbose_name='Descrição')
    quantidade = models.IntegerField(default=1, validators=[MinValueValidator(1)])
    severidade = models.CharField(
        max_length=20,
        choices=[('BAIXA', 'Baixa'), ('MEDIA', 'Média'), ('ALTA', 'Alta'), ('CRITICA', 'Crítica')],
        default='MEDIA',
        verbose_name='Severidade'
    )
    resolvido = models.BooleanField(default=False, verbose_name='Resolvido')
    
    class Meta:
        verbose_name = 'Defeito'
        verbose_name_plural = 'Defeitos'
        ordering = ['-data_hora']
    
    def __str__(self):
        if self.equipamento:
            return f'{self.equipamento.nome} - {self.tipo_defeito}'
        return f'Linha {self.linha.codigo} - {self.tipo_defeito}'
